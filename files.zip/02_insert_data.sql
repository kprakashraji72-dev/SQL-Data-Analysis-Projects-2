-- ============================================
-- Sample Data Insertion
-- Sales Data Analysis Project
-- ============================================

USE sales_db;

-- Insert Customers
INSERT INTO customers (customer_name, email, city, state, country, created_at) VALUES
('Arjun Sharma',    'arjun.sharma@email.com',   'Chennai',    'Tamil Nadu',      'India', '2023-01-10'),
('Priya Nair',      'priya.nair@email.com',      'Coimbatore', 'Tamil Nadu',      'India', '2023-02-14'),
('Rahul Gupta',     'rahul.gupta@email.com',     'Mumbai',     'Maharashtra',     'India', '2023-03-05'),
('Sneha Reddy',     'sneha.reddy@email.com',     'Hyderabad',  'Telangana',       'India', '2023-03-22'),
('Kiran Mehta',     'kiran.mehta@email.com',     'Bangalore',  'Karnataka',       'India', '2023-04-01'),
('Divya Pillai',    'divya.pillai@email.com',    'Kochi',      'Kerala',          'India', '2023-04-18'),
('Arun Kumar',      'arun.kumar@email.com',      'Delhi',      'Delhi',           'India', '2023-05-09'),
('Meena Iyer',      'meena.iyer@email.com',      'Madurai',    'Tamil Nadu',      'India', '2023-05-25'),
('Vijay Patel',     'vijay.patel@email.com',     'Ahmedabad',  'Gujarat',         'India', '2023-06-12'),
('Lakshmi Devi',    'lakshmi.devi@email.com',    'Mysore',     'Karnataka',       'India', '2023-07-03');

-- Insert Products
INSERT INTO products (product_name, category, unit_price, stock_qty) VALUES
('Laptop Pro 15',       'Electronics',   65000.00, 50),
('Wireless Mouse',      'Accessories',    1200.00, 200),
('Mechanical Keyboard', 'Accessories',    3500.00, 150),
('USB-C Hub',           'Accessories',    2200.00, 120),
('27" Monitor',         'Electronics',   22000.00,  40),
('Noise Cancelling Headphones', 'Electronics', 8500.00, 80),
('Webcam HD 1080p',     'Electronics',    4500.00,  90),
('Office Chair',        'Furniture',     12000.00,  30),
('Standing Desk',       'Furniture',     25000.00,  20),
('LED Desk Lamp',       'Accessories',    1800.00, 100);

-- Insert Orders
INSERT INTO orders (customer_id, order_date, status) VALUES
(1,  '2023-01-15', 'Completed'),
(2,  '2023-02-20', 'Completed'),
(3,  '2023-03-10', 'Completed'),
(4,  '2023-04-05', 'Completed'),
(5,  '2023-05-18', 'Completed'),
(6,  '2023-06-22', 'Completed'),
(7,  '2023-07-30', 'Completed'),
(8,  '2023-08-14', 'Completed'),
(9,  '2023-09-09', 'Completed'),
(10, '2023-10-01', 'Completed'),
(1,  '2023-11-11', 'Completed'),
(3,  '2023-12-25', 'Completed'),
(5,  '2024-01-08', 'Completed'),
(7,  '2024-02-14', 'Completed'),
(2,  '2024-03-20', 'Completed');

-- Insert Order Items
INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES
(1,  1, 1, 65000.00),
(1,  2, 2,  1200.00),
(2,  3, 1,  3500.00),
(2,  4, 1,  2200.00),
(3,  5, 1, 22000.00),
(3,  6, 1,  8500.00),
(4,  7, 2,  4500.00),
(4,  8, 1, 12000.00),
(5,  9, 1, 25000.00),
(5, 10, 3,  1800.00),
(6,  1, 1, 65000.00),
(6,  3, 1,  3500.00),
(7,  2, 5,  1200.00),
(7,  4, 2,  2200.00),
(8,  6, 1,  8500.00),
(8,  5, 1, 22000.00),
(9,  1, 2, 65000.00),
(10, 9, 1, 25000.00),
(10, 8, 1, 12000.00),
(11, 7, 1,  4500.00),
(12, 3, 2,  3500.00),
(13, 5, 1, 22000.00),
(14, 1, 1, 65000.00),
(15, 6, 2,  8500.00);
