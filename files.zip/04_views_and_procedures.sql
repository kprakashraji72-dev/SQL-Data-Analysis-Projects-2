-- ============================================
-- Views & Stored Procedures
-- Author: Prakashraji K
-- ============================================

USE sales_db;

-- ─────────────────────────────────────────
-- VIEW 1: Sales Summary per Product
-- ─────────────────────────────────────────
CREATE OR REPLACE VIEW vw_product_sales_summary AS
SELECT 
    p.product_id,
    p.product_name,
    p.category,
    p.unit_price,
    COALESCE(SUM(oi.quantity), 0)               AS total_units_sold,
    COALESCE(SUM(oi.quantity * oi.unit_price), 0) AS total_revenue
FROM products p
LEFT JOIN order_items oi ON p.product_id = oi.product_id
GROUP BY p.product_id, p.product_name, p.category, p.unit_price;

-- Query the view
SELECT * FROM vw_product_sales_summary ORDER BY total_revenue DESC;

-- ─────────────────────────────────────────
-- VIEW 2: Customer Order Summary
-- ─────────────────────────────────────────
CREATE OR REPLACE VIEW vw_customer_order_summary AS
SELECT 
    c.customer_id,
    c.customer_name,
    c.city,
    c.state,
    COUNT(DISTINCT o.order_id)                   AS total_orders,
    COALESCE(SUM(oi.quantity * oi.unit_price), 0) AS total_spent,
    MAX(o.order_date)                             AS last_order_date
FROM customers c
LEFT JOIN orders o      ON c.customer_id = o.customer_id
LEFT JOIN order_items oi ON o.order_id   = oi.order_id
GROUP BY c.customer_id, c.customer_name, c.city, c.state;

-- Query the view
SELECT * FROM vw_customer_order_summary ORDER BY total_spent DESC;

-- ─────────────────────────────────────────
-- VIEW 3: Monthly Revenue Trend
-- ─────────────────────────────────────────
CREATE OR REPLACE VIEW vw_monthly_revenue AS
SELECT 
    DATE_FORMAT(o.order_date, '%Y-%m')       AS month,
    COUNT(DISTINCT o.order_id)               AS total_orders,
    SUM(oi.quantity * oi.unit_price)         AS monthly_revenue,
    ROUND(AVG(oi.quantity * oi.unit_price), 2) AS avg_item_value
FROM orders o
INNER JOIN order_items oi ON o.order_id = oi.order_id
GROUP BY month;

-- Query the view
SELECT * FROM vw_monthly_revenue ORDER BY month;

-- ─────────────────────────────────────────
-- STORED PROCEDURE 1: Get Sales by Category
-- ─────────────────────────────────────────
DELIMITER $$

CREATE PROCEDURE GetSalesByCategory(IN p_category VARCHAR(50))
BEGIN
    SELECT 
        p.product_name,
        SUM(oi.quantity)                AS units_sold,
        SUM(oi.quantity * oi.unit_price) AS revenue
    FROM order_items oi
    INNER JOIN products p ON oi.product_id = p.product_id
    WHERE p.category = p_category
    GROUP BY p.product_name
    ORDER BY revenue DESC;
END$$

DELIMITER ;

-- Usage: CALL GetSalesByCategory('Electronics');

-- ─────────────────────────────────────────
-- STORED PROCEDURE 2: Get Customer Purchase History
-- ─────────────────────────────────────────
DELIMITER $$

CREATE PROCEDURE GetCustomerHistory(IN p_customer_id INT)
BEGIN
    SELECT 
        o.order_id,
        o.order_date,
        p.product_name,
        oi.quantity,
        oi.unit_price,
        (oi.quantity * oi.unit_price) AS line_total
    FROM orders o
    INNER JOIN order_items oi ON o.order_id    = oi.order_id
    INNER JOIN products p     ON oi.product_id = p.product_id
    WHERE o.customer_id = p_customer_id
    ORDER BY o.order_date DESC;
END$$

DELIMITER ;

-- Usage: CALL GetCustomerHistory(1);
