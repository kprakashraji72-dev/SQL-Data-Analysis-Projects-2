-- ============================================
-- Sales Analysis Queries
-- Author: Prakashraji K
-- ============================================

USE sales_db;

-- ─────────────────────────────────────────
-- 1. Total Revenue Generated
-- ─────────────────────────────────────────
SELECT 
    SUM(quantity * unit_price) AS total_revenue
FROM order_items;

-- ─────────────────────────────────────────
-- 2. Total Revenue by Product Category
-- ─────────────────────────────────────────
SELECT 
    p.category,
    SUM(oi.quantity * oi.unit_price) AS category_revenue,
    COUNT(DISTINCT oi.order_id)      AS total_orders
FROM order_items oi
INNER JOIN products p ON oi.product_id = p.product_id
GROUP BY p.category
ORDER BY category_revenue DESC;

-- ─────────────────────────────────────────
-- 3. Top 5 Best-Selling Products by Revenue
-- ─────────────────────────────────────────
SELECT 
    p.product_name,
    p.category,
    SUM(oi.quantity)               AS total_units_sold,
    SUM(oi.quantity * oi.unit_price) AS total_revenue
FROM order_items oi
INNER JOIN products p ON oi.product_id = p.product_id
GROUP BY p.product_id, p.product_name, p.category
ORDER BY total_revenue DESC
LIMIT 5;

-- ─────────────────────────────────────────
-- 4. Monthly Sales Trend
-- ─────────────────────────────────────────
SELECT 
    DATE_FORMAT(o.order_date, '%Y-%m') AS month,
    COUNT(DISTINCT o.order_id)         AS total_orders,
    SUM(oi.quantity * oi.unit_price)   AS monthly_revenue
FROM orders o
INNER JOIN order_items oi ON o.order_id = oi.order_id
GROUP BY month
ORDER BY month ASC;

-- ─────────────────────────────────────────
-- 5. Top Customers by Total Spend
-- ─────────────────────────────────────────
SELECT 
    c.customer_name,
    c.city,
    c.state,
    COUNT(DISTINCT o.order_id)         AS total_orders,
    SUM(oi.quantity * oi.unit_price)   AS total_spent
FROM customers c
INNER JOIN orders o   ON c.customer_id = o.customer_id
INNER JOIN order_items oi ON o.order_id = oi.order_id
GROUP BY c.customer_id, c.customer_name, c.city, c.state
ORDER BY total_spent DESC
LIMIT 5;

-- ─────────────────────────────────────────
-- 6. Revenue by State (Regional Analysis)
-- ─────────────────────────────────────────
SELECT 
    c.state,
    COUNT(DISTINCT c.customer_id)      AS total_customers,
    SUM(oi.quantity * oi.unit_price)   AS state_revenue
FROM customers c
INNER JOIN orders o   ON c.customer_id = o.customer_id
INNER JOIN order_items oi ON o.order_id = oi.order_id
GROUP BY c.state
ORDER BY state_revenue DESC;

-- ─────────────────────────────────────────
-- 7. Average Order Value
-- ─────────────────────────────────────────
SELECT 
    ROUND(AVG(order_total), 2) AS avg_order_value
FROM (
    SELECT 
        order_id,
        SUM(quantity * unit_price) AS order_total
    FROM order_items
    GROUP BY order_id
) AS order_summary;

-- ─────────────────────────────────────────
-- 8. Products Never Ordered (LEFT JOIN)
-- ─────────────────────────────────────────
SELECT 
    p.product_id,
    p.product_name,
    p.category
FROM products p
LEFT JOIN order_items oi ON p.product_id = oi.product_id
WHERE oi.product_id IS NULL;

-- ─────────────────────────────────────────
-- 9. Orders Above Average Order Value
-- ─────────────────────────────────────────
SELECT 
    o.order_id,
    c.customer_name,
    SUM(oi.quantity * oi.unit_price) AS order_total
FROM orders o
INNER JOIN customers c    ON o.customer_id = c.customer_id
INNER JOIN order_items oi ON o.order_id    = oi.order_id
GROUP BY o.order_id, c.customer_name
HAVING order_total > (
    SELECT AVG(order_total)
    FROM (
        SELECT SUM(quantity * unit_price) AS order_total
        FROM order_items
        GROUP BY order_id
    ) AS sub
)
ORDER BY order_total DESC;

-- ─────────────────────────────────────────
-- 10. Yearly Revenue Comparison
-- ─────────────────────────────────────────
SELECT 
    YEAR(o.order_date)               AS year,
    SUM(oi.quantity * oi.unit_price) AS yearly_revenue,
    COUNT(DISTINCT o.order_id)       AS total_orders
FROM orders o
INNER JOIN order_items oi ON o.order_id = oi.order_id
GROUP BY year
ORDER BY year ASC;
